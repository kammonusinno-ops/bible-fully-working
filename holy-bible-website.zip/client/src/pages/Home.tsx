// Sacred Editorial design: Cormorant Garamond + Source Serif 4 + DM Sans; Scripture Green, parchment, antique brass; editorial reading spine.
import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Bookmark, BookmarkCheck, BookOpen, Check, ChevronRight, Compass, Flame, Home as HomeIcon, Menu, Moon, Search, Sparkles, Sun, X } from "lucide-react";
import { toast } from "sonner";

const HERO = "/manus-storage/bible-hero_a51a10f5.jpg";
const STUDY_IMAGE = "/manus-storage/bible-study_9777f070.jpg";
const LANDSCAPE = "/manus-storage/bible-landscape_e405b5fd.jpg";

const OT_BOOKS = [
  ["Genesis",50],["Exodus",40],["Leviticus",27],["Numbers",36],["Deuteronomy",34],["Joshua",24],["Judges",21],["Ruth",4],["1 Samuel",31],["2 Samuel",24],["1 Kings",22],["2 Kings",25],["1 Chronicles",29],["2 Chronicles",36],["Ezra",10],["Nehemiah",13],["Esther",10],["Job",42],["Psalms",150],["Proverbs",31],["Ecclesiastes",12],["Song of Solomon",8],["Isaiah",66],["Jeremiah",52],["Lamentations",5],["Ezekiel",48],["Daniel",12],["Hosea",14],["Joel",3],["Amos",9],["Obadiah",1],["Jonah",4],["Micah",7],["Nahum",3],["Habakkuk",3],["Zephaniah",3],["Haggai",2],["Zechariah",14],["Malachi",4],
].map(([name, chapters]) => ({ name: name as string, chapters: chapters as number, testament: "Old Testament" }));
const NT_BOOKS = [
  ["Matthew",28],["Mark",16],["Luke",24],["John",21],["Acts",28],["Romans",16],["1 Corinthians",16],["2 Corinthians",13],["Galatians",6],["Ephesians",6],["Philippians",4],["Colossians",4],["1 Thessalonians",5],["2 Thessalonians",3],["1 Timothy",6],["2 Timothy",4],["Titus",3],["Philemon",1],["Hebrews",13],["James",5],["1 Peter",5],["2 Peter",3],["1 John",5],["2 John",1],["3 John",1],["Jude",1],["Revelation",22],
].map(([name, chapters]) => ({ name: name as string, chapters: chapters as number, testament: "New Testament" }));
const BOOKS = [...OT_BOOKS, ...NT_BOOKS];
const CATEGORIES: Record<string, string[]> = {
  "The Law": ["Genesis","Exodus","Leviticus","Numbers","Deuteronomy"],
  "History": ["Joshua","Judges","Ruth","1 Samuel","2 Samuel","1 Kings","2 Kings","1 Chronicles","2 Chronicles","Ezra","Nehemiah","Esther"],
  "Wisdom & Poetry": ["Job","Psalms","Proverbs","Ecclesiastes","Song of Solomon"],
  "Prophets": ["Isaiah","Jeremiah","Lamentations","Ezekiel","Daniel","Hosea","Joel","Amos","Obadiah","Jonah","Micah","Nahum","Habakkuk","Zephaniah","Haggai","Zechariah","Malachi"],
  "The Gospels": ["Matthew","Mark","Luke","John"],
  "Early Church": ["Acts"],
  "Paul's Letters": ["Romans","1 Corinthians","2 Corinthians","Galatians","Ephesians","Philippians","Colossians","1 Thessalonians","2 Thessalonians","1 Timothy","2 Timothy","Titus","Philemon"],
  "General Letters": ["Hebrews","James","1 Peter","2 Peter","1 John","2 John","3 John","Jude"],
  "Prophecy": ["Revelation"],
};
const DESCRIPTIONS: Record<string, string> = {
  Genesis: "Beginnings, creation, the patriarchs, and covenant.", Exodus: "Deliverance from Egypt and the giving of the Law.", Psalms: "Songs and prayers for the full range of human experience.", Proverbs: "Practical wisdom for everyday life.", Isaiah: "Judgment, mercy, and the coming Messianic hope.", Matthew: "Jesus as the promised Messiah and King.", Mark: "A fast-paced account of Jesus' ministry and sacrifice.", Luke: "An orderly account of Jesus' life, compassion, and resurrection.", John: "Jesus revealed as the Word made flesh.", Acts: "The birth and spread of the early church through the Spirit.", Romans: "Salvation by grace through faith in Jesus Christ.", Revelation: "Christ's ultimate victory over evil.",
};
const API_BOOK_IDS: Record<string, string> = { Genesis:"GEN", Exodus:"EXO", Leviticus:"LEV", Numbers:"NUM", Deuteronomy:"DEU", Joshua:"JOS", Judges:"JDG", Ruth:"RUT", "1 Samuel":"1SA", "2 Samuel":"2SA", "1 Kings":"1KI", "2 Kings":"2KI", "1 Chronicles":"1CH", "2 Chronicles":"2CH", Ezra:"EZR", Nehemiah:"NEH", Esther:"EST", Job:"JOB", Psalms:"PSA", Proverbs:"PRO", Ecclesiastes:"ECC", "Song of Solomon":"SNG", Isaiah:"ISA", Jeremiah:"JER", Lamentations:"LAM", Ezekiel:"EZK", Daniel:"DAN", Hosea:"HOS", Joel:"JOL", Amos:"AMO", Obadiah:"OBA", Jonah:"JON", Micah:"MIC", Nahum:"NAM", Habakkuk:"HAB", Zephaniah:"ZEP", Haggai:"HAG", Zechariah:"ZEC", Malachi:"MAL", Matthew:"MAT", Mark:"MRK", Luke:"LUK", John:"JHN", Acts:"ACT", Romans:"ROM", "1 Corinthians":"1CO", "2 Corinthians":"2CO", Galatians:"GAL", Ephesians:"EPH", Philippians:"PHP", Colossians:"COL", "1 Thessalonians":"1TH", "2 Thessalonians":"2TH", "1 Timothy":"1TI", "2 Timothy":"2TI", Titus:"TIT", Philemon:"PHM", Hebrews:"HEB", James:"JAS", "1 Peter":"1PE", "2 Peter":"2PE", "1 John":"1JN", "2 John":"2JN", "3 John":"3JN", Jude:"JUD", Revelation:"REV" };
const TRANSLATIONS = { kjv: { label: "KJV English", api: "eng_kjv" }, tagalog: { label: "Tagalog", api: "tgl_ulb" }, ilocano: { label: "Ilocano", api: "ilo_ulb" }, hiligaynon: { label: "Hiligaynon", api: "hil_bib" } } as const;
const BIBLE_API = "https://bible.helloao.org/api";
const VOTD = ["Psalm 23:1", "John 3:16", "Romans 8:28", "Proverbs 3:5", "Isaiah 40:31"];

type Book = { name: string; chapters: number; testament: string };
type Verse = { verse: number; text: string; book_name?: string; chapter?: number; book_id?: string };

function keyFor(book: string, chapter: number, verse: number) { return `${book}-${chapter}-${verse}`; }
function apiBook(book: string) { return API_BOOK_IDS[book] || book.toUpperCase().replaceAll(" ", ""); }
function normalizeBookName(raw: string) { const trimmed = raw.trim(); if (trimmed.toLowerCase() === "psalm") return "Psalms"; return BOOKS.find(book => book.name.toLowerCase() === trimmed.toLowerCase())?.name || trimmed; }
function normalizeChapterContent(content: Array<{ type?: string; number?: number; content?: unknown[] }>, book: Book, chapter: number): Verse[] { return content.filter(item => item.type === "verse" && typeof item.number === "number").map(item => ({ verse: item.number as number, text: (item.content || []).filter(part => typeof part === "string").join(""), book_name: book.name, chapter, book_id: apiBook(book.name) })); }

export default function Home() {
  const [page, setPage] = useState("home");
  const [testament, setTestament] = useState<"Old Testament" | "New Testament">("Old Testament");
  const [translation, setTranslation] = useState(localStorage.getItem("bible_translation") || "kjv");
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [chapter, setChapter] = useState(1);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState("");
  const [search, setSearch] = useState("");
  const [results, setResults] = useState<Verse[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>(() => JSON.parse(localStorage.getItem("bible_bookmarks") || "[]"));
  const [read, setRead] = useState<string[]>(() => JSON.parse(localStorage.getItem("bible_read") || "[]"));
  const [dark, setDark] = useState(true);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [votdIndex, setVotdIndex] = useState(0);
  const [votdText, setVotdText] = useState("Loading today’s reading…");

  useEffect(() => { document.documentElement.classList.toggle("dark", dark); }, [dark]);
  useEffect(() => { localStorage.setItem("bible_bookmarks", JSON.stringify(bookmarks)); }, [bookmarks]);
  useEffect(() => { localStorage.setItem("bible_read", JSON.stringify(read)); }, [read]);
  useEffect(() => { localStorage.setItem("bible_translation", translation); }, [translation]);
  useEffect(() => { fetchPassage(VOTD[votdIndex]).then(data => setVotdText(data[0]?.text?.trim() || "Keep reading, one chapter at a time.")); }, [votdIndex]);

  const visibleBooks = useMemo(() => BOOKS.filter(b => b.testament === testament && b.name.toLowerCase().includes(filter.toLowerCase())), [testament, filter]);
  const startedBooks = new Set(read.map(k => k.split("-")[0])).size;
  const progress = Math.round((startedBooks / BOOKS.length) * 100);

  async function fetchChapter(book: Book, chapterNumber: number): Promise<Verse[]> {
    const response = await fetch(`${BIBLE_API}/${TRANSLATIONS[translation as keyof typeof TRANSLATIONS].api}/${apiBook(book.name)}/${chapterNumber}.json`);
    if (!response.ok) throw new Error("unavailable");
    const data = await response.json();
    return normalizeChapterContent(data.chapter?.content || [], book, chapterNumber);
  }

  async function fetchPassage(reference: string): Promise<Verse[]> {
    const match = reference.trim().match(/^(.*?)\s+(\d+)(?::(\d+)(?:-(\d+))?)?$/);
    if (!match) return [];
    const bookName = normalizeBookName(match[1]);
    const book = BOOKS.find(item => item.name === bookName);
    if (!book) return [];
    try {
      const versesForChapter = await fetchChapter(book, Number(match[2]));
      if (!match[3]) return versesForChapter;
      const start = Number(match[3]); const end = Number(match[4] || match[3]);
      return versesForChapter.filter(item => item.verse >= start && item.verse <= end);
    } catch { return []; }
  }

  async function loadChapter(book: Book, nextChapter: number) {
    setSelectedBook(book); setChapter(nextChapter); setPage("verses"); setLoading(true); setVerses([]);
    setRead(current => current.includes(`${book.name}-${nextChapter}`) ? current : [...current, `${book.name}-${nextChapter}`]);
    try { setVerses(await fetchChapter(book, nextChapter)); }
    catch { toast.error(`${TRANSLATIONS[translation as keyof typeof TRANSLATIONS].label} text could not be loaded. Please try again.`); }
    setLoading(false);
  }

  async function runSearch(event: React.FormEvent) {
    event.preventDefault(); if (!search.trim()) return; setLoading(true); setResults([]);
    const data = await fetchPassage(search.trim()); setResults(data); setLoading(false);
    if (!data.length) toast.error("No matching passage found. Try “John 3:16” or “Psalm 23”.");
  }

  function toggleBookmark(book: string, ch: number, verse: number) {
    const key = keyFor(book, ch, verse); setBookmarks(current => current.includes(key) ? current.filter(k => k !== key) : [...current, key]);
  }
  function go(next: string) { setPage(next); setMobileMenu(false); window.scrollTo({ top: 0, behavior: "smooth" }); }
  function navItems() { return [{ id: "home", label: "Home", icon: HomeIcon }, { id: "browse", label: "Read", icon: BookOpen }, { id: "search", label: "Search", icon: Search }, { id: "bookmarks", label: "Saved", icon: Bookmark }, { id: "study", label: "Study", icon: Sparkles }]; }

  const currentBookmarks = BOOKS.flatMap(book => read.length ? [] : []).length;
  return <div className="app-shell">
    <header className="site-header">
      <button className="brand" onClick={() => go("home")} aria-label="Holy Bible home"><span className="brand-mark"><img src="/manus-storage/holy-bible-mark_ec43afce.png" alt="" /></span><span><strong>HOLY BIBLE</strong><small>OLD & NEW TESTAMENT</small></span></button>
      <nav className={`main-nav ${mobileMenu ? "open" : ""}`}>{navItems().map(({ id, label, icon: Icon }) => <button key={id} className={page === id ? "active" : ""} onClick={() => go(id)}><Icon size={16} /><span>{label}</span>{id === "bookmarks" && bookmarks.length > 0 && <em>{bookmarks.length}</em>}</button>)}</nav>
      <div className="header-actions"><button className="icon-button" onClick={() => setDark(!dark)} aria-label="Toggle theme">{dark ? <Sun size={17} /> : <Moon size={17} />}</button><button className="menu-button" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle menu">{mobileMenu ? <X size={20} /> : <Menu size={20} />}</button></div>
    </header>

    <main>
      {page === "home" && <section className="home-page">
        <div className="hero" style={{ backgroundImage: `linear-gradient(90deg, rgba(12,33,25,.94) 0%, rgba(12,33,25,.74) 50%, rgba(12,33,25,.16) 100%), url(${HERO})` }}><div className="hero-copy"><p className="eyebrow">A quieter place to read</p><h1>Stay with<br /><i>the Word.</i></h1><p className="hero-lede">A calm, multilingual reading room for Scripture, study, and the small daily rhythm of returning to what matters.</p><div className="hero-actions"><button className="brass-button" onClick={() => { setTestament("New Testament"); go("browse"); }}>Begin with Matthew <ArrowRight size={16} /></button><button className="text-button" onClick={() => { setTestament("Old Testament"); go("browse"); }}>Explore all books</button></div></div><div className="hero-note"><span>66</span><small>books<br />to return to</small></div></div>
        <div className="home-grid"><div className="reading-card paper-card"><div className="section-kicker"><span>01</span><span>Verse of the day</span></div><p className="passage-ref">{VOTD[votdIndex]}</p><blockquote>{votdText}</blockquote><button className="quiet-button" onClick={() => setVotdIndex((votdIndex + 1) % VOTD.length)}>Another passage <ArrowRight size={14} /></button></div><div className="progress-card"><div className="section-kicker"><span>02</span><span>Your reading rhythm</span></div><div className="progress-number">{progress}<sup>%</sup></div><p>{startedBooks} of {BOOKS.length} books explored</p><div className="progress-track"><span style={{ width: `${progress}%` }} /></div><button className="quiet-button" onClick={() => go("browse")}>Read where you left off <ArrowRight size={14} /></button></div></div>
        <div className="feature-band" style={{ backgroundImage: `linear-gradient(90deg, rgba(241,233,215,.98) 0%, rgba(241,233,215,.82) 52%, rgba(241,233,215,.12) 100%), url(${STUDY_IMAGE})` }}><div><p className="eyebrow ink">A study companion</p><h2>Choose a book,<br /><i>then stay awhile.</i></h2><p>Move from book to chapter to verse without losing your place. Save the lines you want to carry with you.</p><button className="ink-button" onClick={() => go("bookmarks")}>Open saved verses <ArrowRight size={15} /></button></div></div>
      </section>}

      {page === "browse" && <section className="content-page"><div className="page-heading"><div><p className="eyebrow">The library</p><h1>Books of the Bible</h1><p>Read the complete Old and New Testament in a focused, unhurried view.</p></div><div className="translation-control"><label htmlFor="translation">Translation</label><select id="translation" value={translation} onChange={e => setTranslation(e.target.value)}>{Object.entries(TRANSLATIONS).map(([value, label]) => <option key={value} value={value}>{label.label}</option>)}</select></div></div><div className="testament-tabs"><button className={testament === "Old Testament" ? "active" : ""} onClick={() => setTestament("Old Testament")}>Old Testament <span>39</span></button><button className={testament === "New Testament" ? "active" : ""} onClick={() => setTestament("New Testament")}>New Testament <span>27</span></button></div><div className="filter-row"><Search size={16} /><input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Filter books..." /></div><div className="book-list">{Object.entries(CATEGORIES).filter(([category]) => { const isNT = ["The Gospels","Early Church","Paul's Letters","General Letters","Prophecy"].includes(category); return testament === "New Testament" ? isNT : !isNT; }).map(([category, names]) => { const books = names.map(n => BOOKS.find(b => b.name === n)).filter((b): b is Book => Boolean(b)).filter(b => b.testament === testament && b.name.toLowerCase().includes(filter.toLowerCase())); if (!books.length) return null; return <div className="book-group" key={category}><p className="group-label">{category}</p>{books.map(book => <button className="book-row" key={book.name} onClick={() => { setSelectedBook(book); go("chapters"); }}><span className="book-initial">{book.name.charAt(0)}</span><span className="book-info"><strong>{book.name}</strong><small>{DESCRIPTIONS[book.name] || "A book to read, reflect on, and return to."}</small></span><span className="book-meta">{book.chapters} ch <ChevronRight size={17} /></span></button>)}</div>; })}</div></section>}

      {page === "chapters" && selectedBook && <section className="content-page"><button className="back-link" onClick={() => go("browse")}><ArrowLeft size={15} /> Back to books</button><div className="chapter-heading"><div><p className="eyebrow">{selectedBook.testament}</p><h1>{selectedBook.name}</h1><p>{DESCRIPTIONS[selectedBook.name] || "Read this book at your own pace."}</p></div><span className="chapter-count">{selectedBook.chapters}<small>chapters</small></span></div><div className="chapter-grid">{Array.from({ length: selectedBook.chapters }, (_, index) => index + 1).map(number => <button key={number} className={read.includes(`${selectedBook.name}-${number}`) ? "read" : ""} onClick={() => loadChapter(selectedBook, number)}><span>{number}</span>{read.includes(`${selectedBook.name}-${number}`) && <Check size={12} />}</button>)}</div></section>}

      {page === "verses" && selectedBook && <section className="reader-page"><div className="reader-top"><button className="back-link" onClick={() => go("chapters")}><ArrowLeft size={15} /> Back to chapters</button><div className="reader-nav"><button disabled={chapter <= 1} onClick={() => loadChapter(selectedBook, chapter - 1)}><ArrowLeft size={15} /> Prev</button><button disabled={chapter >= selectedBook.chapters} onClick={() => loadChapter(selectedBook, chapter + 1)}>Next <ArrowRight size={15} /></button></div></div><div className="reader-title"><p className="eyebrow">{TRANSLATIONS[translation as keyof typeof TRANSLATIONS].label} · {selectedBook.testament}</p><h1>{selectedBook.name} <i>{chapter}</i></h1></div>{loading ? <div className="loading-state"><span />Opening the page…</div> : verses.length ? <div className="verse-list">{verses.map(verse => { const saved = bookmarks.includes(keyFor(selectedBook.name, chapter, verse.verse)); return <button className={`verse ${saved ? "saved" : ""}`} key={verse.verse} onClick={() => toggleBookmark(selectedBook.name, chapter, verse.verse)}><span className="verse-number">{verse.verse}</span><span className="verse-text">{verse.text.trim()}</span><span className="verse-save">{saved ? <BookmarkCheck size={17} /> : <Bookmark size={17} />}</span></button>; })}</div> : <div className="empty-reading"><BookOpen size={28} /><h2>Choose a supported passage</h2><p>This chapter is unavailable or the reference could not be understood. Try another chapter or a reference such as “John 3:16”.</p></div>}</section>}

      {page === "search" && <section className="content-page narrow"><div className="page-heading"><div><p className="eyebrow">Find a passage</p><h1>Search Scripture</h1><p>Enter a reference such as “John 3:16” or “Psalm 23”.</p></div></div><form className="search-form" onSubmit={runSearch}><Search size={18} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Reference or keyword" /><button className="brass-button" type="submit">Search</button></form>{loading && <div className="loading-state"><span />Searching the library…</div>}<div className="search-results">{results.map((verse, index) => <div className="result" key={`${verse.verse}-${index}`}><p>{verse.book_name} {verse.chapter}:{verse.verse}</p><blockquote>{verse.text?.trim()}</blockquote></div>)}</div></section>}

      {page === "bookmarks" && <section className="content-page narrow"><div className="page-heading"><div><p className="eyebrow">Your study shelf</p><h1>Saved verses</h1><p>{bookmarks.length ? "Lines you chose to carry with you." : "Your saved verses will gather here as you read."}</p></div></div>{bookmarks.length ? <div className="saved-list">{bookmarks.map(key => { const [book, ch, verse] = key.split("-"); return <div className="saved-item" key={key}><BookmarkCheck size={18} /><div><p>{book} {ch}:{verse}</p><small>Saved from your reading session</small></div><button onClick={() => setBookmarks(bookmarks.filter(item => item !== key))}><X size={16} /></button></div>; })}</div> : <div className="empty-reading"><Bookmark size={28} /><h2>Nothing saved yet</h2><p>Open a chapter and tap any verse to keep it here.</p><button className="ink-button" onClick={() => go("browse")}>Browse books <ArrowRight size={15} /></button></div>}</section>}

      {page === "study" && <section className="content-page study-page"><div className="study-hero" style={{ backgroundImage: `linear-gradient(90deg, rgba(25,56,42,.96), rgba(25,56,42,.45)), url(${LANDSCAPE})` }}><p className="eyebrow">A small invitation</p><h1>Read slowly.<br /><i>Notice more.</i></h1><p>Use this space for a question, a theme, or the passage you want to revisit. The best study session often begins with one honest question.</p></div><div className="prompt-grid"><button onClick={() => { setSearch("John 3:16"); go("search"); }}><Sparkles size={18} /><strong>Begin with a familiar verse</strong><span>Search John 3:16</span></button><button onClick={() => { setTestament("Old Testament"); setFilter("Psalms"); go("browse"); }}><Compass size={18} /><strong>Spend time in the Psalms</strong><span>Open a book of prayer</span></button><button onClick={() => { setTestament("New Testament"); setFilter(""); go("browse"); }}><Flame size={18} /><strong>Follow the story forward</strong><span>Explore the New Testament</span></button></div></section>}
    </main>
    <footer><span>✦ HOLY BIBLE</span><span>Read with attention. Return with hope.</span></footer>
  </div>;
}
