# Real Translation Data Integration

- [x] Identify a reliable public source for Tagalog Scripture text and confirm its license or usage terms.
- [x] Identify a reliable public source for Ilocano Scripture text and confirm its license or usage terms.
- [x] Identify a reliable public source for Hiligaynon Scripture text and confirm its license or usage terms.
- [x] Normalize the selected API chapter payloads into the reader's chapter/verse model.
- [x] Replace the legacy API-only fallback with the Free Use Bible API translation IDs and preserve KJV behavior.
- [x] Verify Tagalog Genesis 1 chapter loading and rendered verse text in the live website.
- [x] Verify Ilocano chapter loading and rendered verse text in the live website.
- [x] Verify Hiligaynon Genesis 1 payload availability and normalization through the same real API adapter.
- [ ] Save a new website checkpoint and deliver the updated version.
