# Philippine-language Scripture data research

The current `bible-api.com` source supports public-domain/free-license Bibles but its literal `tagalog`, `ilocano`, and `hiligaynon` identifiers returned 404 during earlier testing.

The `seven1m/open-bibles` repository explicitly lists a public-domain Tagalog Bible (Ang Dating Biblia) and provides XML files for public-domain or freely licensed translations: https://github.com/seven1m/open-bibles

The Bible SuperSearch SourceForge directory provides a Tagalog JSON export (`tagab.json`) and states that its Bibles are legally shareable and reshareable for non-commercial purposes, subject to each Bible's copyright statement: https://sourceforge.net/projects/biblesuper/files/All%20Bibles%20-%20JSON/TL-Tagalog/

The `Beblia/Holy-Bible-XML-Format` repository advertises 200+ languages and 1000+ Bible versions in XML, but its landing page says “use at your own discretion” and does not provide a clear license statement. It should not be used for a public website until the exact files and rights are confirmed: https://github.com/Beblia/Holy-Bible-XML-Format

The Free Use Bible API documentation says it provides over 1000 translations in JSON and offers downloadable datasets, with endpoints shaped like `https://bible.helloao.org/api/{translation}/books.json`: https://bible.helloao.org/docs/reference/ and https://bible.helloao.org/docs/guide/downloads.html

The `get.bible` data-set guide notes that many translations are copyrighted and require permission or licensing, while APIs such as Bible Brain, API.Bible, YouVersion Platform, and Bible SuperSearch offer controlled access: https://get.bible/bible-data-sets/

The next step is to query the Free Use Bible API translation index for exact Tagalog, Ilocano, and Hiligaynon identifiers, then verify representative chapter payloads and source/license metadata before integrating.
