# Holy Bible Website Design Direction

## Three Directions Considered

### Theme Name: Sacred Editorial
Very Brief Intro: A quiet, premium reading environment inspired by independent Christian publishing, archival paper, and forest-shadowed study rooms. The interface should feel devotional without becoming ornamental.
Probability: 0.07

### Theme Name: Dawn & Dust
Very Brief Intro: A warmer, light-first interpretation built around sunrise landscapes, parchment, and generous open space. It emphasizes hope, clarity, and approachable daily reading.
Probability: 0.04

### Theme Name: Monastic Ledger
Very Brief Intro: A restrained, typographic system with ink, linen, and brass accents, borrowing from annotated manuscripts and archival catalogues. It makes navigation feel deliberate and scholarly.
Probability: 0.08

## Chosen Approach: Sacred Editorial

### Design Movement
Contemporary editorial design with references to independent publishing, quiet luxury, and devotional print ephemera.

### Core Principles
1. Reading comes first: Scripture text remains the visual anchor and uses generous line-height and measured measure.
2. Contrast should feel natural: deep forest, parchment, and brass create warmth without relying on loud gradients.
3. Structure is contextual: books, chapters, and verses appear as a clear editorial sequence rather than a generic dashboard grid.
4. Every control should feel like part of a study ritual: calm, tactile, and easy to revisit.

### Color Philosophy
Deep forest green establishes stillness and focus; parchment cream keeps long reading sessions comfortable; antique brass marks action, saved verses, and meaningful progress. The signature color is **Scripture Green** `#19382a`, chosen to feel ownable, grounded, and distinct from generic blue application palettes.

### Layout Paradigm
Use an asymmetrical editorial shell: a persistent narrow rail for identity and navigation, a wide reading canvas for Scripture, and offset content blocks for home and study surfaces. Avoid a centered collection of equal cards; instead, create a clear reading spine with secondary context tucked around it.

### Signature Elements
- A brass open-book mark with a subtle cross-shaped negative space.
- Fine rule lines and chapter markers that echo printed page furniture.
- Quiet paper-grain textures and image crops that feel like collected editorial plates.

### Interaction Philosophy
Interactions should be calm and legible. Hover states lift slightly and brighten the brass edge; saved verses receive a warm bookmark treatment; navigation changes should feel like turning a page, never like switching dashboards.

### Animation
Use short 160–220ms ease-out transitions for buttons and tabs. Stagger book-list entry by 30ms only on first load. Verse navigation fades the reading canvas by a few pixels vertically. Respect reduced-motion preferences and remove nonessential transforms when requested.

### Typography System
Display: `Cormorant Garamond` for page titles and large editorial headlines. Body: `Source Serif 4` for Scripture and descriptive copy. UI labels: `DM Sans` at compact sizes for navigation, filters, and metadata. Use italic serif sparingly for verse-of-the-day emphasis.

### Brand Essence
A calm, multilingual Bible reading room for people who want to study Scripture across both Testaments without distraction. Personality: grounded, reverent, generous.

### Brand Voice
Headlines are invitational and specific; CTAs are short and active; microcopy is warm but never generic. Example lines: “Read where you left off.” “Choose a book, then stay awhile.”

### Wordmark & Logo
Use the generated open-book mark as the symbol. Pair it with a small-caps `HOLY BIBLE` wordmark in DM Sans with expanded tracking, never a default system wordmark.

### Signature Brand Color
Scripture Green — `#19382a`.
